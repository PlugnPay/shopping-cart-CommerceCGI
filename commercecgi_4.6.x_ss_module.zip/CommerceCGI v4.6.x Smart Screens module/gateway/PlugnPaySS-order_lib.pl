#######################################################################
# 
#  CommerceCGI 4.6.1 Payment Module
#  PlugnPay Smart Screen Payment Method
# 
#  Last Update: 03/28/07
# 
#######################################################################

#######################################################################
# Gateway Notes
#######################################################################

# Please refer to PnP's 'Integration Specifications' document for
# additional info on how our smart screens payment method fields.

#######################################################################
# Gateway Variables
#######################################################################

# These are the values that are used by the manager to configure this gateway.

%sc_gateway_settings = (
  'sc_gateway_url',             'Payment Script URL:<br><font size=\"-1\"><i>Use \'https://pay1.plugnpay.com/payment/pay.cgi\' unless otherwise advised by PnP tech support.</i></font>',
  'sc_gateway_publisher_name',  'PlugnPay Username:',
  'sc_gateway_publisher_email', 'Merchant Email:<br><font size=\"-1\"><i>i.e. you@yourdomain.com</i></font>',
  'sc_gateway_card_allowed',    'Cards Allowed:<br><font size=\"-1\"><i>i.e. Visa,Mastercard,Amex,Discover</i></font>',
  'sc_gateway_shipinfo',        'Collect Shipping Address Info:<br><font size=\"-1\"><i>Set \'1\' for Yes.  Set \'0\' for No</i></font>'
);

# The process variable is the unique variable that is passed by this gateway that tells us
# that it is time to call the process order sub.

$process_variable{'PlugnPaySS'} = "FinalStatus";

# This tells us what the variable name is that contails the cart id
# when returning from the gateway.

$return_cart_id_variable{'PlugnPaySS'} = "cart_id";

# Image name and description that will show up on the view cart screen for this gateway.

$check_out_image{'PlugnPaySS'}  = "complete_order.gif";
$check_out_detail{'PlugnPaySS'} = "Pay by Credit Card!";

###############################################################################
# Gateway Prep
###############################################################################

sub PlugnPaySS_gateway_prep {
  # We set the ship-to address values to be the same as the bill-to values
  # if the ship-to values are blank.

  if (! $form_data{'shipname'}) { $form_data{'ship_name'} = $form_data{'card-name'}; }
  if (! $form_data{'address1'}) { $form_data{'address1'} = $form_data{'card-address1'}; }
  if (! $form_data{'city'}) { $form_data{'city'} = $form_data{'card-city'}; }
  if (! $form_data{'state'}) { $form_data{'state'} = $form_data{'card-state'}; }
  if (! $form_data{'zip'}) { $form_data{'zip'} = $form_data{'card-zip'}; }
  if (! $form_data{'country'}) { $form_data{'country'} = $form_data{'card-country'}; }

  $form_data{'misc_var_a'} = $form_data{'misc_var_a'};
  $form_data{'misc_var_b'} = $form_data{'misc_var_b'};
  $form_data{'misc_var_c'} = $form_data{'misc_var_c'};
  $form_data{'misc_var_d'} = $form_data{'misc_var_d'};
  $form_data{'misc_var_e'} = $form_data{'misc_var_e'};

  # These are misc. variables that we need to set up.

  $INVOICE     = $time;
  #$DESCRIPTION = "Online Order";

  if (!($sc_gateway_user_lib_was_loaded =~ /yes/i)) {
    require "$sc_configuration_directory_path/PlugnPaySS-user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/$sc_gateway_name-user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
  }

  #$sequence = int(rand 1000);
  #$fp = &hmac_hex($sc_gateway_publisher_name ."^".$sequence."^".$INVOICE."^".$pass_grand_total."^",'txnkey');

  #$Relay_Response = "True";
  #Show_Form      = "PAYMENT_FORM";
  $Cart_Client = "CommerceCGIv4.x";

  # These are the variables that need to be passed to the checkout process/gateway
  # The first part is what we want to call the variable when it is passed.
  # The second part is what variable we are going to use.
  # Pass name, Variable name to use.

  $sc_passthrough_variables->{'client'}                 = 'Cart_Client';
  $sc_passthrough_variables->{'publisher-name'}         = 'sc_gateway_publisher_name';
  $sc_passthrough_variables->{'publisher-email'}        = 'sc_gateway_publisher_email';
  $sc_passthrough_variables->{'card-allowed'}           = 'sc_gateway_card_allowed';
  $sc_passthrough_variables->{'shipping'}               = 'pass_final_shipping';
  $sc_passthrough_variables->{'tax'}                    = 'pass_final_sales_tax';
  $sc_passthrough_variables->{'discount'}               = 'pass_final_discount';
  $sc_passthrough_variables->{'subtotal'}               = 'pass_subtotal';
  $sc_passthrough_variables->{'card-amount'}            = 'pass_grand_total';
  $sc_passthrough_variables->{'shippingmethod'}         = 'shipMethod';
  $sc_passthrough_variables->{'order-id'}               = 'INVOICE';
  $sc_passthrough_variables->{'cart_id'}                = 'cart_id';
  #$sc_passthrough_variables->{'sequence'}               = 'sequence';
  $sc_passthrough_variables->{'timestamp'}              = 'INVOICE';
  #$sc_passthrough_variables->{'fp_hash'}                = 'fp';
  #$sc_passthrough_variables->{'Relay_Response'}         = 'Relay_Response';
  $sc_passthrough_variables->{'success-link'}           = 'sc_order_script_url';
  #$sc_passthrough_variables->{'badcard-link'}           = 'sc_order_script_url';
  #$sc_passthrough_variables->{'problem-link'}           = 'sc_order_script_url';
  #$sc_passthrough_variables->{'Show_Form'}              = 'Show_Form';
  #$sc_passthrough_variables->{'Description'}            = 'DESCRIPTION';
  $sc_passthrough_variables->{'misc_var_a'}             = 'misc_var_a';
  $sc_passthrough_variables->{'misc_var_b'}             = 'misc_var_b';
  $sc_passthrough_variables->{'misc_var_c'}             = 'misc_var_c';
  $sc_passthrough_variables->{'misc_var_d'}             = 'misc_var_d';
  $sc_passthrough_variables->{'misc_var_e'}             = 'misc_var_e';

  # This is the same as above but instead of variables we are using $form_date{'values'}
  # for the second part.
  # Pass form_data, Order form name.

  # $sc_passthrough_form_data->{''}      = '';

  # This is a list of the form values on the order form and an actual description of what this
  # field actually is. This is used to display an error message to the screen if this is a
  # required field and it is not filled in.

  $sc_order_form_array->{'Ecom_ShipTo_Postal_StateProv'} =  'Shipping Address State';
  $sc_order_form_array->{'upgradeShipping'}              =  'Shipping Method';

  # This is a list of the required fields on the order form.

  push(@sc_order_form_required_fields, "Ecom_ShipTo_Postal_StateProv");
  push(@sc_order_form_required_fields, "upgradeShipping");

  # Fields to replace in templates (Emails, and log files), form post value to replace with.

  $form_data{'card-name'} = "$form_data{'card-fname'} $form_data{'card-lname'}";
  $form_data{'shipname'} = "$form_data{'card-fname'} $form_data{'card-lname'}";

  $sc_process_order_fields->{'INVOICE'} =       'orderID';
  $sc_process_order_fields->{'cart_id'} =       'card_id';
  $sc_process_order_fields->{'NAME'} =          'card-name';
  $sc_process_order_fields->{'ADDRESS'} =       'card-address1';
  $sc_process_order_fields->{'CITY'} =          'card-city';
  $sc_process_order_fields->{'STATE'} =         'card-state';
  $sc_process_order_fields->{'ZIP'} =           'card-zip';
  $sc_process_order_fields->{'COUNTRY'} =       'card-country';
  $sc_process_order_fields->{'PHONE'} =         'phone';
  $sc_process_order_fields->{'FAX'} =           'fax';
  $sc_process_order_fields->{'EMAIL'} =         'email';
  $sc_process_order_fields->{'SHIPNAME'} =      'shipname';
  $sc_process_order_fields->{'SHIPTOSTREET'} =  'address1';
  $sc_process_order_fields->{'SHIPTOCITY'} =    'city';
  $sc_process_order_fields->{'SHIPTOSTATE'} =   'state';
  $sc_process_order_fields->{'SHIPTOZIP'} =     'zip';
  $sc_process_order_fields->{'SHIPTOCOUNTRY'} = 'country';
  $sc_process_order_fields->{'SHIPTOPHONE'} =   'shipphone';
  $sc_process_order_fields->{'SHIPTOFAX'} =     'shipfax';
  $sc_process_order_fields->{'SHIPTOEMAIL'} =   'shipemail';
  $sc_process_order_fields->{'SUBTOTAL'} =      'subtotal';
  $sc_process_order_fields->{'SHIPPING'} =      'shipping';
  $sc_process_order_fields->{'SHIPMETHOD'} =    'shippingmethod';
  $sc_process_order_fields->{'SALESTAX'} =      'tax';
  $sc_process_order_fields->{'DISCOUNT'} =      'discount';
  $sc_process_order_fields->{'AMOUNT'} =        'card-amount';
  $sc_process_order_fields->{'METHOD'} =        'NULL';
  $sc_process_order_fields->{'EXPDATE'} =       'NULL';

  $sc_process_custom_order_fields->{'SHIPCOMPANY'} =   'shipcompany';
  $sc_process_custom_order_fields->{'COMPANY'} =       'company';
  $sc_process_custom_order_fields->{'RES'} =           'FinalStatus';
  $sc_process_custom_order_fields->{'RESSUB'} =        'sresp';
  $sc_process_custom_order_fields->{'RESCODE'} =       'resp-code';
  $sc_process_custom_order_fields->{'RESTEXT'} =       'MErrMsg';
  $sc_process_custom_order_fields->{'AVSCODE'} =       'avs-code';
  $sc_process_custom_order_fields->{'TRANSID'} =       'orderID';
  $sc_process_custom_order_fields->{'AUTHCODE'} =      'auth-code';
}

###############################################################################
# Display the order form
###############################################################################

sub PlugnPaySS_display_order_form {
  local ($line, $subtotal, $total_quantity, $total_measured_quantity);
  local ($text_of_cart, $hidden_fields_for_cart, $AllshipMethods);
  local ($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($time);
  $year += 1900;
  # $year = substr($year,2,2);

  $cc_year = $year;

  while ($cc_year <= ($year + 10)) {
    $cc_years .= "<option>$cc_year</option>\n";
    $cc_year++;
    #if ($cc_year < 10 && substr($cc_year,0,1) ne "0") {
    #  $cc_year = "0" . $cc_year;
    #}
  }

  open(SHIPPING, "$sc_log_file_directory_path/shipping.txt") || &errorcode(__FILE__, __LINE__, "$sc_log_file_directory_path/shipping.txt", "$!", "print", "FILE OPEN ERROR", "1");
  while (<SHIPPING>) {
    @ship_options = split(/\|/, $_);
    $AllshipMethods .= "<OPTION VALUE=\"$ship_options[0]|$ship_options[1]\">$ship_options[1]</OPTION>\n";
  }
  close (SHIPPING);

  &display_cart_table("orderform");

  for $i (1..6) {
    $letter_index = int(rand 994);
    $secret_images .= qq~<img src="image.cgi?i=$letter_index">~;
    $secret_letter = $rand_key[$letter_index];
    $secret_word .= $secret_letter;
  }

  $hidden_security_key = &hmac_hex($secret_word ."^",$encrypt_key);

  if (!($sc_gateway_user_lib_was_loaded =~ /yes/i)) {
    require "$sc_configuration_directory_path/PlugnPaySS-user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/$sc_gateway_name-user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
  }

  print qq~
    <!-- Start Orderform -->
    </FORM>
    <FORM METHOD="post" ACTION="$sc_order_script_url">
    <INPUT TYPE="hidden" NAME="page" VALUE="$form_data{'page'}">
    <INPUT TYPE="hidden" NAME="cart_id" VALUE="$cart_id">
    <INPUT TYPE="hidden" NAME="gateway" VALUE="PlugnPaySS">

    <TABLE WIDTH="90%" BORDER="0">

    $PlugnPaySS_order_form_top1
    $PlugnPaySS_order_form_top2

    <tr>
      <TD ALIGN="CENTER">
        <p align="right"><FONT FACE="ARIAL" SIZE="2" COLOR="#000000"><b>Please select ship to STATE:&nbsp;</b></FONT></p>
      </TD>
      <TD ALIGN="RIGHT"><p align="left">
        <SELECT NAME="Ecom_ShipTo_Postal_StateProv" size="1">
        <OPTION>$form_data{'Ecom_ShipTo_Postal_StateProv'}</OPTION>
        <OPTION>AK</OPTION>
        <OPTION>AL</OPTION>
        <OPTION>AR</OPTION>
        <OPTION>AZ</OPTION>
        <OPTION>CA</OPTION>
        <OPTION>CO</OPTION>
        <OPTION>CT</OPTION>
        <OPTION>DC</OPTION>
        <OPTION>DE</OPTION>
        <OPTION>FL</OPTION>
        <OPTION>GA</OPTION>
        <OPTION>GU</OPTION>
        <OPTION>HI</OPTION>
        <OPTION>IA</OPTION>
        <OPTION>ID</OPTION>
        <OPTION>IL</OPTION>
        <OPTION>IN</OPTION>
        <OPTION>KS</OPTION>
        <OPTION>KY</OPTION>
        <OPTION>LA</OPTION>
        <OPTION>MA</OPTION>
        <OPTION>MD</OPTION>
        <OPTION>ME</OPTION>
        <OPTION>MI</OPTION>
        <OPTION>MN</OPTION>
        <OPTION>MO</OPTION>
        <OPTION>MS</OPTION>
        <OPTION>MT</OPTION>
        <OPTION>NC</OPTION>
        <OPTION>ND</OPTION>
        <OPTION>NE</OPTION>
        <OPTION>NH</OPTION>
        <OPTION>NJ</OPTION>
        <OPTION>NM</OPTION>
        <OPTION>NV</OPTION>
        <OPTION>NY</OPTION>
        <OPTION>OH</OPTION>
        <OPTION>OK</OPTION>
        <OPTION>OR</OPTION>
        <OPTION>PA</OPTION>
        <OPTION>PR</OPTION>
        <OPTION>RI</OPTION>
        <OPTION>SC</OPTION>
        <OPTION>SD</OPTION>
        <OPTION>TN</OPTION>
        <OPTION>TX</OPTION>
        <OPTION>UT</OPTION>
        <OPTION>VA</OPTION>
        <OPTION>VI</OPTION>
        <OPTION>VT</OPTION>
        <OPTION>WA</OPTION>
        <OPTION>WI</OPTION>
        <OPTION>WV</OPTION>
        <OPTION>WY</OPTION>
        </SELECT><font size="2" color="#FF0000" face="Arial">$form_data{'Ecom_ShipTo_Postal_StateProv_error'}</font>
        </p>
      </TD>
    </tr>
    <tr>
      <TD ALIGN="CENTER">
        <p align="right"><FONT FACE="ARIAL" SIZE="2" COLOR="#000000"><b>Select shipping method:&nbsp;</b></FONT></p>
      </TD>
      <TD ALIGN="RIGHT">
        <p align="left">

        <!-- Shipping Options (PlugnPaySS-orderform.html-->
        <SELECT NAME="upgradeShipping" size="1">
        <OPTION VALUE="$form_data{'upgradeShipping'}">$shipMethod</OPTION>
        $AllshipMethods
        </select>
        <!-- End Shipping Options -->

        <font size="2" color="#FF0000" face="Arial">$form_data{'upgradeShipping_error'}</font>
        </p>
      </TD>
    </tr>

    <tr>
      <TD COLSPAN="2" ALIGN="CENTER">&nbsp;</TD>
    </tr>

    <TR>
      <TD valign="top">
        <p align="right"><font face="Arial" size="2"><b>Security Check:</b></font></p>
      </TD>

      <TD>
        <p>$secret_images
        <INPUT TYPE="hidden" NAME="hidden_security_key" VALUE="$hidden_security_key"></p>
        <p><font face="Arial">Enter the letters that you see above:
        <input type="text" name="security_key" size="20">&nbsp;&nbsp;<br>
        </font><font color="#FF0000" size="2" face="Arial">$form_data{'security_key_error'}</font>
        </p>
      </TD>
    </TR>

    <TR>
      <TD COLSPAN="2">
        <P align="center"></P>
      </TD>
    </TR>

    <TR>
      <TD COLSPAN="2">
        <p align="center"><INPUT TYPE=submit NAME = "submit_order_form_button"  VALUE = "Please Click Here To Continue">
      </TD>
    </TR>

    $PlugnPaySS_order_form_bottom1
    $PlugnPaySS_order_form_bottom2

    </TABLE>

    </center>
    </div>
    </CENTER>

    </FORM>
    <!-- End PlugnPaySS orderform -->
   ~;

   &StoreFooter("regular");

} # End of display_order_form

###############################################################################
# Print Submit Page where they verify the order
###############################################################################

sub PlugnPaySS_printSubmitPage {

  &PlugnPaySS_gateway_prep;

  if (!($sc_gateway_user_lib_was_loaded =~ /yes/i)) {
    require "$sc_configuration_directory_path/PlugnPaySS-user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/$sc_gateway_name-user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");
  }

  print qq~
    </FORM>
    <FORM METHOD=POST ACTION=\"$sc_gateway_url\">
    <!--Customer/Order Data-->
    <hr noshade size="1" color="#000000" width="90%">
    <INPUT TYPE = "hidden" NAME = "gateway" VALUE = "PlugnPaySS">
  ~;

  while (my ($pass_key, $pass_value) = each(%$sc_passthrough_form_data)) {
    print "<INPUT TYPE=\"hidden\" NAME=$pass_key VALUE=\"$form_data{$pass_value}\">\n";
  }

#  $encypt_code = "$pass_grand_total $pass_final_shipping $pass_final_discount $pass_final_sales_tax";
#  $control     = &hmac_hex($encypt_code, $encrypt_key);
#  print "<INPUT TYPE=\"HIDDEN\" NAME=\"USER8\" VALUE=\"$control\">\n";

  ($shipKey, $shipMethod) = split(/\|/, $form_data{'upgradeShipping'});

  while (my ($pass_key, $pass_value) = each(%$sc_passthrough_variables)) {
    print "<INPUT TYPE=\"hidden\" NAME=$pass_key VALUE=\"${$pass_value}\">\n";
    $mypage =~ s/\{$pass_key\}/${$pass_value}/g;
  }

  print qq~
    <!-- Start confirmation -->
    <div align="center">
    <center>
    <TABLE WIDTH="90%" CELLPADDING="2" CELLSPACING="0">
      <TR>
        <TD>&nbsp;</TD>
      </TR>

      <TR>
        <TD><FONT FACE="ARIAL" SIZE="2"><b>Please verify the above information and when you are confident
          that it is correct, click the 'Continue to SECURE ORDER FORM' button below.</b></FONT></TD>
      </TR>

      <TR>
        <TD>&nbsp;</TD>
      </TR>

      <TR>
        <TD COLSPAN=2><CENTER>
          <P><INPUT TYPE="HIDDEN" NAME="process_order" VALUE="yes">
          <br>&nbsp; <INPUT TYPE=SUBMIT VALUE="Continue to SECURE ORDER FORM">
          <P></CENTER></TD>
       </TR>
       </TABLE>
       </CENTER>
       </FONT>
       </center>
       </div>
      <!-- End confirmation -->
   ~;
}
###############################################################

sub PlugnPaySS_processOrder {
  local($subtotal, $total_quantity, $total_measured_quantity, $text_of_cart,
       $required_fields_filled_in, $product, $quantity, $options,
        $text_of_confirm_email, $text_of_admin_email, $emailCCnum, $logCCnum);

  if ($form_data{'FinalStatus'} eq "success") {
    &PlugnPaySS_gateway_prep;

    #$encypt_code = "$form_data{'AMOUNT'} $form_data{'SHIPPING'} $form_data{'DISCOUNT'} $form_data{'SALESTAX'}";
    #$control     = &hmac_hex($encypt_code, $encrypt_key);
    #if ($control ne $form_data{'control'}) {
    #  &errorcode(__FILE__, __LINE__, "Control number", "Control number does not match", "die", "CONTROL NUMBER MISS MATCH", "9");
    #}

    $orderDate = &get_date;

    require "$sc_configuration_directory_path/pgp_user_lib.pl" || &errorcode(__FILE__, __LINE__, "$sc_configuration_directory_path/pgp_user_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");

    if ($sc_use_pgp =~ /yes/i) {
      $emailCCnum    = $form_data{'CARDNUM'};
      $logCCnum      = $form_data{'CARDNUM'};
    }
    else {
      $emailCCnum    = "XXXXXXXX";
      $emailCCnum   .= substr($form_data{'CARDNUM'},8,20);
      $logCCnum      = substr($form_data{'CARDNUM'},0,8);
      $logCCnum     .= "XXXXXXXX";
    }

    ##############################################################
    # Here we generate the html cart header code.
    ##############################################################

    $product_html       .= qq~<tr>~;
    $admin_product_html .= qq~<tr>~;

    $display_counter = 0;
    foreach (@sc_cart_display_fields) {
      if ($sc_cart_index_for_display[$display_counter] == $cart{"price"} ||
          $sc_cart_index_for_display[$display_counter] == $cart{"shipping"} ||
          $sc_cart_index_for_display[$display_counter] == $cart{"price_after_options"}) {
        $product_html .= qq~
          <td bgColor="#000080" align="right">
            <p align="right"><strong><font face="Arial" size="2" color="#FFFFFF">
            $_
            </font></strong>
          </td>
        ~;
      }
      else {
        $product_html .= qq~
          <td bgColor="#000080" align="left">
            <p align="left"><strong><font face="Arial" size="2" color="#FFFFFF">
            $_
            </font></strong>
          </td>
        ~;
      }
      $display_counter++;
    }

    $display_counter = 0;
    foreach (@sc_cart_display_fields) {
      if ($sc_cart_index_for_admin_email[$display_counter] == $cart{"price"} ||
          $sc_cart_index_for_admin_email[$display_counter] == $cart{"shipping"} ||
          $sc_cart_index_for_admin_email[$display_counter] == $cart{"price_after_options"})
      {
        $admin_product_html .= qq~
          <td bgColor="#000080" align="right">
            <p align="right"><strong><font face="Arial" size="2" color="#FFFFFF">
            $_
            </font></strong>
          </td>
        ~;
      }
      else {
        $admin_product_html .= qq~
          <td bgColor="#000080" align="left">
            <p align="left"><strong><font face="Arial" size="2" color="#FFFFFF">
            $_
            </font></strong>
          </td>
        ~;
      }
      $display_counter++;
    }

    $product_html       .= qq~</tr><tr>~;
    $admin_product_html .= qq~</tr><tr>~;

    ##############################################################
    # Open Cart to generate product information
    ##############################################################

    open (CART, "$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR", "0");
    while (<CART>) {
      $cartData++;
      @cart_fields   = split (/\|/, $_);

      $cart_fields[$cart{"price"}]               = &display_price(&format_price($cart_fields[$cart{"price"}]));
      $cart_fields[$cart{"shipping"}]            = &display_price(&format_price($cart_fields[$cart{"shipping"}]));
      $cart_fields[$cart{"price_after_options"}] = &display_price(&format_price($cart_fields[$cart{"price_after_options"}] * $cart_fields[$cart{"quantity"}]));

      ##############################################################
      # Generate the html version of products for customer email
      ##############################################################

      $admin_display_counter = 0;
      foreach $field (@sc_cart_index_for_display) {
        if ($field == $cart{"price"} || $field == $cart{"shipping"} || $field == $cart{"price_after_options"}) {
          $product_html .= qq~<td vAlign="top" align="right"><font face="Arial" size="2">$cart_fields[$field]</font></td>~;
        }
        elsif ($field == $cart{"options"}) {
          $cart_fields[$field]  =~ s/<br>/ /g;
          $product_html .= qq~</tr><tr><td></td><td vAlign="top" align="left" colspan="$field"><font face="Arial" size="2">$cart_fields[$field]</font></td></tr>~;
        }
        else {
           $product_html .= qq~<td vAlign="top" align="left"><font face="Arial" size="2">$cart_fields[$field]</font></td>~;
        }
        $admin_display_counter++;
      }

      ##############################################################
      # Generate the html version of products for admin email and log
      ##############################################################

      $display_counter = 0;
      foreach $field (@sc_cart_index_for_admin_html) {
        if ($field == $cart{"price"} || $field == $cart{"shipping"} || $field == $cart{"price_after_options"}) {
          $admin_product_html .= qq~<td vAlign="top" align="right"><font face="Arial" size="2">$cart_fields[$field]</font></td>~;
        }
        elsif ($field == $cart{"options"}) {
          $cart_fields[$field]  =~ s/<br>/ /g;
          $admin_product_html .= qq~</tr><tr><td></td><td vAlign="top" align="left" colspan="$field"><font face="Arial" size="2">$cart_fields[$field]</font></td></tr>~;
        }
        else {
          $admin_product_html .= qq~<td vAlign="top" align="left"><font face="Arial" size="2">$cart_fields[$field]</font></td>~;
        }
        $display_counter++;
      }

      ##############################################################
      # Generate the text version of products for customer email
      ##############################################################

      $d_counter = 0;
      foreach $field (@sc_cart_index_for_email) {
        if ($field == $cart{"price"} || $field == $cart{"shipping"} || $field == $cart{"price_after_options"}) {
          $product_text .= "$sc_cart_email_fields[$d_counter]\:      $cart_fields[$field]\n";
        }
        else {
          $product_text .= "$sc_cart_email_fields[$d_counter]\:      $cart_fields[$field]\n";
        }
        $d_counter++;
      }
      $product_text .= "\n";

      ##############################################################
      # Generate the text version of products for admin email and log
      ##############################################################

      $d_counter = 0;
      foreach $field (@sc_cart_index_for_admin_email) {
        if ($field == $cart{"price"} || $field == $cart{"shipping"} || $field == $cart{"price_after_options"}) {
          $admin_product_text .= "$sc_cart_display_admin_email[$d_counter]\:      $cart_fields[$field]\n";
        }
        else {
          $admin_product_text .= "$sc_cart_display_admin_email[$d_counter]\:      $cart_fields[$field]\n";
        }
        $d_counter++;
      }
      $admin_product_text .= "\n";
    }
    close(CART);

    $display_counter = $display_counter - 2;
    $admin_display_counter = $admin_display_counter - 2;

    if ($cartData) {
      open (EMAIL, "$sc_template_directory_path/email.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/email.txt", "$!", "print", "FILE OPEN ERROR", "0");
      while (<EMAIL>) { $text_of_confirm_email .= $_; }
      close (EMAIL);

      open (EMAIL, "$sc_template_directory_path/admin_email.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/admin_email.txt", "$!", "print", "FILE OPEN ERROR", "0");
      while (<EMAIL>) { $text_of_admin_email .= $_; }
      close (EMAIL);

      open (EMAIL, "$sc_template_directory_path/admin_log.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/admin_log.txt", "$!", "print", "FILE OPEN ERROR", "0");
      while (<EMAIL>) { $text_of_log .= $_; }
      close (EMAIL);

      while (my ($pass_key, $pass_value) = each(%$sc_process_order_fields)) {
        if ($pass_key eq 'SUBTOTAL' || $pass_key eq 'SHIPPING' || $pass_key eq 'SALESTAX' ||
            $pass_key eq 'DISCOUNT' || $pass_key eq 'AMOUNT') {
          $form_data{$pass_value} = &display_price(&format_price($form_data{$pass_value}));
        }

        $text_of_confirm_email =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
        $text_of_admin_email   =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
        $text_of_log           =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
      }

      while (my ($pass_key, $pass_value) = each(%$sc_process_custom_order_fields)) {
        $text_of_admin_email   .= "$pass_key\: $form_data{$pass_value}\n";
        $text_of_log           .= "$pass_key\: $form_data{$pass_value}\n";
      }

      $text_of_confirm_email =~ s/\{product_text\}/$product_text/g;
      $text_of_confirm_email =~ s/\{product_html\}/$product_html/g;
      $text_of_confirm_email =~ s/\{colSpan\}/$display_counter/g;
      $text_of_confirm_email =~ s/\{date\}/$orderDate/g;

      $text_of_admin_email   =~ s/\{product_text\}/$admin_product_text/g;
      $text_of_admin_email   =~ s/\{product_html\}/$admin_product_html/g;
      $text_of_admin_email   =~ s/\{colSpan\}/$d_counter/g;
      $text_of_admin_email   =~ s/\{date\}/$orderDate/g;
      $text_of_admin_email   =~ s/\{emailCCnum\}/$emailCCnum/g;

      $text_of_log           =~ s/\{product_text\}/$admin_product_text/g;
      $text_of_log           =~ s/\{product_html\}/$admin_product_html/g;
      $text_of_log           =~ s/\{colSpan\}/$d_counter/g;
      $text_of_log           =~ s/\{date\}/$orderDate/g;
      $text_of_log           =~ s/\{logCCnum\}/$logCCnum/g;

      if ($sc_use_pgp =~ /yes/i) {
        require "$sc_library_directory_path/pgp_lib.pl" ||
        &errorcode(__FILE__, __LINE__, "$pgp_temp_folder/pgp_lib.pl", "$!", "die", "FILE REQUIRE ERROR", "8");

        $text_of_log = &make_pgp_file($text_of_log, "$sc_log_file_directory_path/$$.pgp");
        $text_of_log = "\n" . $text_of_log . "\n";

        $text_of_admin_email = &make_pgp_file($text_of_admin_email, "$pgp_temp_folder/$$.pgp");
        $text_of_admin_email = "\n" . $text_of_admin_email . "\n";
      }

      if ($sc_send_order_to_email =~ /yes/i) {
        if (!($sc_mail_lib_was_loaded =~ /yes/i)) {
          require "$sc_mail_lib_path" || &errorcode(__FILE__, __LINE__, "$sc_mail_lib_path", "$!", "die", "FILE REQUIRE ERROR", "8");
        }

        &send_mail($form_data{'email'}, $sc_order_email, "Commerce.cgi Order: $form_data{'USER5'}",$text_of_admin_email);

        if ($sc_order_email_two) {
          &send_mail($form_data{'email'}, $sc_order_email_two, "Commerce.cgi Order: $form_data{'INVOICE'}",$text_of_admin_email);
        }

        if ($sc_order_email_three) {
          &send_mail($form_data{'email'}, $sc_order_email_three, "Commerce.cgi Order: $form_data{'INVOICE'}",$form_data{'card-amount'});
        }
      }

      $log_invoice = $form_data{'orderID'};
      $log_invoice =~ /([0-9]+)/;
      $log_invoice = $1;

      open (ORDERLOG, "+>>$sc_order_directory_path/$log_invoice") || &errorcode(__FILE__, __LINE__, "INVOICE $log_invoice", "$!", "print", "ERROR SAVING ORDER TO SERVER", "4");
      print ORDERLOG $text_of_log;
      close (ORDERLOG);

      chmod ($new_cart_permissions, "$sc_order_directory_path/$log_invoice");

      if (!($sc_mail_lib_was_loaded =~ /yes/i)) {
        require "$sc_mail_lib_path" || &errorcode(__FILE__, __LINE__, "$sc_mail_lib_path", "$!", "die", "FILE REQUIRE ERROR", "8");
      }

      &send_mail($sc_admin_email, $form_data{'email'}, "Thank you for your order!", "$text_of_confirm_email");

      # This empties the cart after the order is successful

      open (CART, ">$sc_cart_path") || &errorcode(__FILE__, __LINE__, "$sc_cart_path", "$!", "print", "FILE OPEN ERROR: ERROR CLEARING SHOPPING CART!", "0");
      close (CART);
      unlink $sc_cart_path;
    }

    # First, we output the header of
    # the processing of the order

    &StoreHeader("Thank you for your order","secure");

    open (THANKYOU, "$sc_template_directory_path/thankyou.txt") || &errorcode(__FILE__, __LINE__, "$sc_template_directory_path/thankyou.txt", "$!", "print", "FILE OPEN ERROR", "0");
    while (<THANKYOU>) {
      $thankyou_page .= $_;
    }
    close (THANKYOU);

    $thankyou_page =~ s/\{scriptURL\}/$sc_store_url/g;

    while (my ($pass_key, $pass_value) = each(%$sc_process_order_fields)) {
      $thankyou_page =~ s/\{$pass_key\}/$form_data{$pass_value}/g;
    }

    print $thankyou_page;

    # and the footer is printed

    &StoreFooter("secure");
  }
  else {
    &StoreHeader("Order Failed!","secure");

    print "<p>$form_data{'FinalStatus'} \- $form_data{'resp-code'}) $form_data{'MErrMsg'}</p>\n";

    if ($form_data{'FinalStatus'} =~ /badcard|fraud/) {
      $message = "There was a problem with your order<BR><BR>";
    }
    else {
      $message = "<p>There was an internal error while processing your order!</p><p>Please use your browser back button and retry your order</p>";
    }

    print "$message";

    &StoreFooter("secure");
  }
} # End of process_order_form

#################################################################

1;
