=================================================
Plug 'n Pay - Smart Screens Method
Payment Module for CommerceCGI v4.6.x
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the CommerceCGI community at
'www.commerce-cgi.com', and if you are still unable to resolve the issue, contact us
via PlugnPay's Online Helpdesk.

This module is used without having your own server's SSL abilities. We will ask the
customer for all of their credit card info on our SSL secured billing page on our
secured servers.  The authorization will be done via PlugnPay's Smart Screens payment
method.  The module DOES NOT itemize the order in the PlugnPay system using
available information from the cart.  For this info, you will need to use the cart's
order tracking ability & it's email notifications to see what the customer purchased.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized CommerceCGI modules will not be provided
support assistance.
***************************

Installation:

For a default CommerceCGI installation, simply upload the provided gateway file into
the cart's 'gateway' folder and activate in the CommerceCGI admin area.

If you run into problems:

Check to be sure you actually uploaded the gateway file in the correct folder.

Check the uploaded file's permissions:
-- .pl files should be chmod 755
   (read/write/execute by owner, read/execute by all others)

These are the common issues found by our support staff.


Some Processing Errors could include:

Hacking Warnings:

This module requires all PnP clients to use a POST method back to their site.
If you have a problem with the connection made from our gateway back to your shopping
cart, please check your PnP admin area to ensure your account is not using our GET method
(transition page).  You must have your account setup to use a POST method back to your site.
You would set it this way by unchecking the 'Use Transition Page' option, within the
'Payment Script Features' section of your PnP admin area.

-----------------------------------------------------------------------------
Updates:

03/28/07
- created initial [beta] smart screens payment module to work with CommerceCGI v4.6.1.

